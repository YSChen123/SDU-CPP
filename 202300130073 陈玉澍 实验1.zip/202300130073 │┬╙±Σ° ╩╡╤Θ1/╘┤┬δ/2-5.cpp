#include <iostream>
using namespace std;
#include <climits>
int main()
{
	cout << "Min of short is: " << SHRT_MIN << endl;
	cout << "Max of short is: " << SHRT_MAX << endl;
	cout << "Min of int is: " << INT_MIN << endl;
	cout << "Max of int is: " << INT_MAX << endl;
	cout << "Min of long is: " << LONG_MIN << endl;
	cout << "Max of long is: " << LONG_MAX << endl;
	cout << "Max of unsigned short is: " << USHRT_MAX << endl;
	cout << "Max of unsigned int is: " << UINT_MAX << endl;
	cout << "Max of unsigned long is: " << ULONG_MAX << endl;
	return 0;
}