#include <iostream>
using namespace std;
int main()
{
	cout << 'A' << ' ' << 'a' << endl;
	cout << "one\ttwo\tthree\n";
	cout << "123\b\b45\n";
	cout << "Alert\a\n";
	return 0;
}