#include <iostream>
using namespace std;
#include <cstdlib>
int rollDice()
{
	int d1 = rand() % 6 + 1;
	int d2 = rand() % 6 + 1;
	int sum = d1 + d2;
	cout<< "player rolled " << d1 << " + " << d2 << " = " << sum << endl;
	return sum;
}
enum GameStatus{WIN,LOSE,PLAYING};
int main()
{
	unsigned seed;
	cout << "Please enter an unsigned integer: " << endl;
	cin >> seed;
	srand(seed);
	int sum, myPoint;
	GameStatus status;
	sum = rollDice();
	switch (sum)
	{
	case 7:
	case 11:
		status = WIN;
		break;
	case 2:
	case 3:
	case 12:
		status = LOSE;
		break;
	default:
		{
			status = PLAYING;
			myPoint = sum;
			cout << "point is: " << myPoint << endl;
			break;
		}
	}
	while (sum == PLAYING)
	{
		sum = rollDice();
		if (sum == myPoint)
		{
			status = WIN;
		}
		else if (sum == 7)
		{
			status = LOSE;
		}
	}
	if (status == WIN)
	{
		cout << "player wins" << endl;
	}
	else
	{
		cout << "player loses" << endl;
	}
	return 0;
}