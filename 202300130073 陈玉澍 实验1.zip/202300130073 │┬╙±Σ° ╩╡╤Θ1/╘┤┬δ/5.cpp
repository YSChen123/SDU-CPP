#include <iostream>
using namespace std;
#include <cstdlib>
enum GameStatus { WIN, LOSE, PLAYING };
class DICE
{
public:
	DICE();
	int rollDice();
	void Game();
	void showResult();
private:
	GameStatus status;
	int sum;
	int myPoint;
};
DICE::DICE()
{
	status = PLAYING;
	sum = 0;
	myPoint = 0;
}

int DICE::rollDice()
{
	int d1 = rand() % 6 + 1;
	int d2 = rand() % 6 + 1;
	sum = d1 + d2;
	cout << "player rolled " << d1 << " + " << d2 << " = " << sum << endl;
	return sum;
}
void DICE::Game()
{
	sum = rollDice();
	switch (sum)
	{
	case 7:
	case 11:
		status = WIN;
		break;
	case 2:
	case 3:
	case 12:
		status = LOSE;
		break;
	default:
	{
		status = PLAYING;
		myPoint = sum;
		cout << "point is: " << myPoint << endl;
		break;
	}
	}
	while (sum == PLAYING)
	{
		sum = rollDice();
		if (sum == myPoint)
		{
			status = WIN;
		}
		else if (sum == 7)
		{
			status = LOSE;
		}
	}
}
void DICE::showResult()
{
	if (status == WIN)
	{
		cout << "player wins" << endl;
	}
	else
	{
		cout << "player loses" << endl;
	}
}
int main()
{
	int seed = 0;
	cout << "Please enter an unsigned integer: " << endl;
	cin >> seed;
	srand(seed);
	DICE d1;
	d1.Game();
	d1.showResult();
	return 0;
}
