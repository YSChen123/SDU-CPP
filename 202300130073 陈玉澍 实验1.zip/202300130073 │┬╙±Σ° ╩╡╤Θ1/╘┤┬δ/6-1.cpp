#include <iostream>
using namespace std;
class Tree
{
public:
	Tree(int a=0)
	{
		ages = a;
	}
	~Tree()
	{
		age();
	}
	void grow(int years)
	{
		ages += years;
	}
	void age()
	{
		cout << "�����������Ϊ�� " << ages << endl;
	}
private:
	int ages;
};

int main()
{
	Tree t(12);
	t.age();
	t.grow(4);
	return 0;
}