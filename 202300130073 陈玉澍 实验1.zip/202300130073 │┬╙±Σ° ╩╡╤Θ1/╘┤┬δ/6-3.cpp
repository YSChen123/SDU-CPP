#include <iostream>
using namespace std;
class Complex
{
public:
	Complex(double r,double i);
	void show();
	void add(Complex c);
private:
	double real;
	double image;
};
Complex::Complex(double r=0, double i=0)
{
	real = r;
	image = i;
}
void Complex::show()
{
	cout << this->real << "+"
		<< this->image << "i" << endl;
}
void Complex::add(Complex c)
{
	this->real += c.real;
	this->image += c.image;
}
int main()
{
	Complex c1(1.5, 2.5);
	Complex c2 = 4.5;
	c1.show();
	c1.add(c2);
	c1.show();
	return 0;
}