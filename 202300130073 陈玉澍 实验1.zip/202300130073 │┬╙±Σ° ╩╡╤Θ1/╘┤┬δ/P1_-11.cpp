#include <stdio.h>
int main()
{
	int x=-1,z=2147483647;
	unsigned int y=x;   

	printf("x=%d,y=%u z=%d\n",x,y,z+1); 
} 
