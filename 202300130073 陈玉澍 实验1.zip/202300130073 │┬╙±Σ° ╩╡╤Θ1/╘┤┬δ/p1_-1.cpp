#include <iostream>
using namespace std;
int main()
{
	int a = 0, b = 0;
	cout << b++ << " " << b++ << " " << b++ << endl;
	cout << ++a << " " << ++a << " " << ++a << " " << endl;
	cout << "a=" << a << endl;
	cout << "b=" << b << endl;

}