#include <iostream>
using namespace std;
int main(){
	int a=0,b=0;
	cout<<"1 "<<"2 "<<"3 "<<endl;
	cout<<b++<<" "<<b++<<" "<<b++<<endl;
	cout<<++a<<" "<<++a<<" "<<++a<<endl;  
	return 0; 
}
