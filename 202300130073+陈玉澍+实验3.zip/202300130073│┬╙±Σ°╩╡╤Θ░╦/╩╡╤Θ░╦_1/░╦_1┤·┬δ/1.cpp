#include <iostream>
using namespace std;
class Complex {
public:
	Complex(double r = 0.0, double i = 0.0) :real(r), imag(i) {	}
	Complex operator + (const Complex& c2)const;
	Complex operator - (const Complex& c2)const;
	void display();
	
	//friend Complex operator+(const Complex& c1, const Complex& c2);
	//friend Complex operator-(const Complex& c1, const Complex& c2);
	
	/*Complex(double r):real(r),imag(0.0){}
	Complex(double r,double i):real(r),imag(i){}
	Complex():real(0),imag(0){}*/
private:
	double real;
	double imag;
};
Complex Complex::operator +(const Complex& c2)const {
	return Complex(real + c2.real, imag + c2.imag);
}
Complex Complex::operator -(const Complex& c2)const {
	return Complex(real - c2.real, imag - c2.imag);
}
void Complex::display() {
	cout << "(" << real << "," << imag << ")" << endl;
}

//Complex operator+(const Complex& c1, const Complex& c2) {
//	return Complex(c1.real + c2.real, c1.imag + c2.imag);
//}
//Complex operator-(const Complex& c1, const Complex& c2) {
//	return Complex(c1.real - c2.real, c1.imag - c2.imag);
//}

int main() {
	Complex c1(5, 4), c2(2, 10), c3;
	cout << "c1 = " ;
	c1.display();
	cout << "c2 = " ;
	c2.display();

	c3 = c1 - c2;
	cout << "c3=c1-c2=" ;
	c3.display();
	c3 = c1 + c2;
	cout << "c3=c1+c2=";
	c3.display();

	/*c3 = Complex(1.0) + c2;
	c3.display();
	c3 = c2 + 1.0;
	c3.display();
	c3 = Complex(2) + c2;
	c3.display();
	c3 = c2 + 2;
	c3.display();*/
	return 0;
}


