#include <iostream>
using namespace std;

class Point {
public:
	Point() { _x = 0, _y = 0; }
	int x() { return _x; }
	int y() { return _y; }
	
	Point &operator++();
	Point operator++(int);

	Point& operator--();
	Point operator--(int);
private:
	int _x, _y;
};
Point &Point::operator++() {
	_x++;
	_y++;
	return *this;
}
Point Point::operator++(int) {
	Point temp = *this;
	++(*this);
	return temp;
}
Point& Point::operator--() {
	_x--;
	_y--;
	return *this;
}
Point Point::operator--(int) {
	Point temp = *this;
	--(*this);
	return temp;
}

int main() {
	Point a;
	cout << "a��ֵΪ��" << a.x() << "," << a.y() << endl;
	a++;
	cout << "a��ֵΪ��" << a.x() << "," << a.y() << endl;
	++a;
	cout << "a��ֵΪ��" << a.x() << "," << a.y() << endl;
	a--;
	cout << "a��ֵΪ��" << a.x() << "," << a.y() << endl;
	--a;
	cout << "a��ֵΪ��" << a.x() << "," << a.y() << endl;
	return 0;
}

