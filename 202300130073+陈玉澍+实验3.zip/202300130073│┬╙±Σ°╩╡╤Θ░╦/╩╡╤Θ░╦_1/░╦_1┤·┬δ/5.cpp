#include <iostream>
using namespace std;

class vehicle {
public:
	//void run() { cout << "vehicle run!" << endl; }
	//void stop(){ cout << "vehicle stop!" << endl; }
	virtual void run() { cout << "vehicle run!" << endl; }
	virtual void stop() { cout << "vehicle stop!" << endl; }
};
class bicycle :virtual public vehicle {
public:
	void run() { cout << "bicycle run!" << endl; }
	void stop() { cout << "bicycle stop!" << endl; }
};
class motorcar :virtual public vehicle {
public:
	void run() { cout << "motorcar run!" << endl; }
	void stop() { cout << "motorcar stop!" << endl; }
};
class motorcycle :public bicycle, public motorcar {
public:
	void run() { cout << "motorcycle run!" << endl; }
	void stop() { cout << "motorcycle stop!" << endl; }
};

int main() {
	vehicle v;
	v.run();
	v.stop();
	bicycle b;
	b.run();
	b.stop();
	motorcar mcar;
	mcar.run();
	mcar.stop();
	motorcycle mcycle;
	mcycle.run();
	mcycle.stop();

	vehicle* ptr = &v;
	ptr->run();
	ptr->stop();
	
	ptr = &b;
	ptr->run();
	ptr->stop();

	ptr = &mcar;
	ptr->run();
	ptr->stop();

	ptr = &mcycle;
	ptr->run();
	ptr->stop();

	return 0;

}