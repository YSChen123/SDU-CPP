#include <iostream>
using namespace std;

class Shape {
public:
	Shape(){}
	virtual  ~Shape(){}
	virtual float getArea() = 0;
	virtual float getPerim() = 0;
};
class Rectangle :public Shape {
public:
	Rectangle(float len, float wid) :itsLen(len), itsWid(wid) {};
	~Rectangle() {};
	virtual float getArea() { return itsLen * itsWid; }
	float getPerim() { return 2 * itsLen + 2 * itsWid; }
	virtual float GetLength() { return itsLen; }
	virtual float GetWidth() { return itsWid; }
private:
	float itsLen;
	float itsWid;
};
class Circle :public Shape {
public:
	Circle(float radius):itsRadius(radius) {}
	~Circle() {}
	float getArea() { return 3.14 * itsRadius * itsRadius; }
	float getPerim() { return 3.14 * 2 * itsRadius; }
private:
	float itsRadius;
};

int main() {
	Shape* sp;
	sp = new Circle(5);
	cout << "The area of the Circle is " << sp->getArea() << endl;
	cout << "The perimeter of the Circle is " << sp->getPerim() << endl;
	delete sp;
	sp = new Rectangle(4, 6);
	cout << "The area of the Rectangle is " << sp->getArea() << endl;
	cout << "The perimeter of the Rectangle is " << sp->getPerim() << endl;
	delete sp;
	return 0;
}
