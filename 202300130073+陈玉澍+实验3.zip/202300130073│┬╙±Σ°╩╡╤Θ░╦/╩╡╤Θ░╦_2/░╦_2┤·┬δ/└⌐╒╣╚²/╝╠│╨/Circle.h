#ifndef _CIRCLE_H_
#define _CIRCLE_H_
#include "Shape.h"
#include "Point.h"
#include <iostream>
using namespace std;
class Circle:public Shape {
public:
	Circle(const Point& center,float radius) :center(center), itsRadius(radius) {}
	virtual void show() {
		cout << "Circle center:(" << center.getX() << "," << center.getY() << ")"
			<< " radius:" << itsRadius << endl;
	}
	Point getC() { return Point(center.getX(), center.getY()); }
	float getR()const { return itsRadius; }
private:
	Point center;
	float itsRadius;
};
#endif // !_CIRCLE_H_
