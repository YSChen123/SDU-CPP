#ifndef _RECTANGLE_H_
#define _RECHTANGLE_H_
#include "Shape.h"
#include "Point.h"
#include <iostream>
using namespace std;

class Rectangle :public Shape {
public:
	Rectangle(const Point& upleft, float w, float h) 
		:upleft(upleft),h(h),w(w){}
	virtual void show(){
		cout << "Rectangle upleft:(" << upleft.getX() << "," << upleft.getY() << ")"
			<< " width:" << w << " height:" << h << endl;
	}
	float getH()const { return h; }
	float getW()const { return w; }
private:
	Point upleft;
	float w, h;
};
#endif