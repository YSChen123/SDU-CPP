#ifndef _UI_H_
#define _UI_H_
#include<vector>
#include "Shape.h"
using namespace std;

class UI {
public:
	vector<Shape*> shapeVector;
	void show() {
		for (int i = 0; i < shapeVector.size(); i++) {
			shapeVector[i]->show();
		}
	}
};
#endif // !_UI_H_
