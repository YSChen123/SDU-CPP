#ifndef _UI_H
#define _UI_H
#include <vector>
#include "Point.h"
#include "Line.h" 
#include "Rectangle.h" 
#include "Circle.h"

class UI { 
public:
	vector<Point> pointVector;
	vector<Line> lineVector;  
	vector<Rectangle> rectVector;  
	vector<Circle>cirVector;

	void show() {
		for (int i = 0; i < pointVector.size(); i++) 
			pointVector[i].show();

		for (int i = 0; i < lineVector.size(); i++)  
			lineVector[i].show();

		for (int i = 0; i < rectVector.size(); i++) 
			rectVector[i].show();

		for (int i = 0; i < cirVector.size(); i++)
			cirVector[i].show();
	}
};
#endif 