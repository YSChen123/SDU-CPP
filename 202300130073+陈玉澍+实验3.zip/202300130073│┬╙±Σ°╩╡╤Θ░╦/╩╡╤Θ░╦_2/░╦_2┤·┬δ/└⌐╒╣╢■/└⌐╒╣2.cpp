#include <iostream>
using namespace std;

class Complex {
public:
	Complex(double r):real(r),imag(0.0){}
	Complex():real(0.0),imag(0.0){}
	Complex(double r ,double i):real(r),imag(i){}
	void display()const {
		cout << "(" << real << "," << imag << ")" << endl;
	}
	Complex operator+(const Complex& c) {
		return Complex(this->real + c.real, this->imag + c.imag);
	}
	/*operator double() {
		return real;
	}*/
private:
	double  real;
	double imag;
};
int main() {
	Complex c1,c2(9,10);
	c1 = 1.2;
	c1.display();
	c1 =c2+1.2;
	c1.display();
	c1 = c2 + 'a';
	c1.display();
	//Complex c1(1.2, 2.3);
    //double d = c1 + 1.3;
    //cout << d << endl;
	return 0;
}