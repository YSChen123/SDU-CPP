#include <iostream>
using namespace std;

class SimpleCircle {
public:
	SimpleCircle();
	SimpleCircle(int);
	SimpleCircle(const SimpleCircle&);
	~SimpleCircle();
	void setRadius(int);
	int getRadius()const;

	//����=�����������
	SimpleCircle operator=(const SimpleCircle &rhs);
private:
	int* itsRadius;
};
SimpleCircle SimpleCircle::operator=(const SimpleCircle& rhs) {
	if (this != &rhs) {
		delete itsRadius;
		itsRadius = new int(rhs.getRadius());
	}
	return *this;
}
SimpleCircle::SimpleCircle() {
	itsRadius = new int(5);
}
SimpleCircle::SimpleCircle(int radius) {
	itsRadius = new int(radius);
}
SimpleCircle::SimpleCircle(const SimpleCircle& rhs) {
	int val = rhs.getRadius();
	itsRadius = new int(val);
}
void SimpleCircle::setRadius(int radius) {
	*itsRadius = radius;
}
int SimpleCircle::getRadius()const {
	return *itsRadius;
}
SimpleCircle::~SimpleCircle() {
	delete itsRadius;
}
int main() {
	SimpleCircle CircleOne, CircleTwo(9),CircleThree;
	cout << "CircleOne:" << CircleOne.getRadius() << endl;
	cout << "CircleTwo:" << CircleTwo.getRadius() << endl;
	CircleThree = CircleTwo = 12;
	cout << "�����,����������ֵ����" << endl;
	cout << "CircleTwo:" << CircleTwo.getRadius() << endl;
	cout << "CircleThree:" << CircleThree.getRadius() << endl;
	return 0;
}

