#include "BigInteger.h"
#include <iostream>
using namespace std;

int main() {
	BigInteger a("10000000000000000000000000000000");
	BigInteger b("2000000000000000000000000000000");

	cout << "a + b = " << a + b << endl;
	cout << "a - b = " << a - b << endl;
	cout << "a * b = " << a * b << endl;
	cout << "a / b = " << a / b << endl;
	return 0;
}