#include <iostream>
using namespace std;

class Cat
{
public:
	Cat(int age):itsAge(age)
	{
		numOfCats++;
	}
	virtual ~Cat() {
		numOfCats--;
	}
	virtual int getAge()
	{
		return itsAge;
	}
	virtual void setAge(int age)
	{
		itsAge = age;
	}
	static int getNumOfCats()
	{
		return numOfCats;
	}
	void telepathicFunction()
	{
		cout << "There are " << Cat::getNumOfCats() << " cats alive!\n";
	}
private:
	int itsAge;
	static int numOfCats;
};
int Cat::numOfCats = 0;
int main()
{
	const int maxCats = 5;
	Cat* catHouse[maxCats];
	for (int i = 0; i < maxCats; i++)
	{
		catHouse[i] = new Cat(i);
		(*catHouse[i]).telepathicFunction();
	}
	for (int i = 0; i < maxCats; i++)
	{
		delete catHouse[i];
		(*catHouse[i]).telepathicFunction();
	}
	return 0;
}
