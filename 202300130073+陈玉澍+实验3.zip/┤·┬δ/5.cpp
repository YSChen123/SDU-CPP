#include <iostream>
using namespace std;

class fuel;
class engine
{
	friend class fuel;
public:
	engine() { powerlevel = 0; }
	void engine_fn(fuel& f);
private:
	int powerlevel;
};
class fuel
{
	friend class engine;
private:
	int fuelLevel;
public:
	fuel() { fuelLevel = 0; }
	void fuel_fn(engine& e);
};
int main()
{

}