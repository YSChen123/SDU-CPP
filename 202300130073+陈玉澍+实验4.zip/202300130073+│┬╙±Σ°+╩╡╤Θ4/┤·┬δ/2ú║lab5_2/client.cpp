#include "client.h"
CLIENT::CLIENT(){
	ClientNum++;
}
void CLIENT::ChangeServerName(char a) {
	ServerName = a;
}

int CLIENT::getClientNumber() {
	return ClientNum;
}
int CLIENT::ClientNum = 0;
char CLIENT::ServerName = 's';