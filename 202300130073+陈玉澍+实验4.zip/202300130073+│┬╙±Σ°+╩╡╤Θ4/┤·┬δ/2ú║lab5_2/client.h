#include <iostream>
using namespace std;
class CLIENT {
public:
	CLIENT();
	static void ChangeServerName(char a);
	static int getClientNumber();
	static char ServerName;
	static int ClientNum;
};