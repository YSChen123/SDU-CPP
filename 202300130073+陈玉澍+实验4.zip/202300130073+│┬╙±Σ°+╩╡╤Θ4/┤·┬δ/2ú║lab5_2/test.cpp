#include <iostream>
using namespace std;
#include "client.h"
int main()
{
	cout << "ClientNumber is " << CLIENT::getClientNumber() << endl;
	CLIENT a;
	cout << "add CLIENT:a" << endl;
	cout << "ClientNumber is "<<CLIENT::getClientNumber() << endl;
	CLIENT b;
	cout << "add CLIENT:b" << endl;
	cout << "ClientNumber is " << CLIENT::getClientNumber() << endl;
	CLIENT c;
	cout << "add CLIENT:c" << endl;
	cout << "ClientNumber is " << CLIENT::getClientNumber() << endl;
	cout << "Before change ServerName��" << endl;
	cout << CLIENT::ServerName << endl;
	cout << "After change ServerName: " << endl;
	CLIENT::ChangeServerName('x');
	cout << CLIENT::ServerName << endl;
	return 0;
}