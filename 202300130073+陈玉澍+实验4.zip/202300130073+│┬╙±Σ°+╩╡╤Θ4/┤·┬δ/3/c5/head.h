#ifndef HEAD_H 
#define HEAD_H
class Point
{
  
};
#endif

