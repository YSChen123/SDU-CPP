//main.cpp
#include "student.h"

int main()
{
	Student stud(101,"zhangsan",'m');
	stud.display();
	return 0;
}
