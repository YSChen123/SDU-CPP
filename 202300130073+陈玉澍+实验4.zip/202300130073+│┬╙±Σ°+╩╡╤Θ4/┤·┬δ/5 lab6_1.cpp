#include <iostream>
using namespace std;
#define SIZE 3
class Matrix {
public:
	Matrix();
	void set();
	void transpose();
	void print();
private:
	int matrix[SIZE][SIZE];
};
Matrix::Matrix() {
	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++) {
			matrix[i][j] = 0;
		}
	}
}
void Matrix::set() {
	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++) {
			cin >> matrix[i][j];
		}
	}
}
void Matrix::transpose() {
	for (int i = 0; i < SIZE; i++) {
		for (int j =i+1; j < SIZE; j++) {
			int tem = matrix[i][j];
			matrix[i][j] = matrix[j][i];
			matrix[j][i] = tem;
		}
	}
}
void Matrix::print() {
	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++) {
			cout << matrix[i][j] << "  ";
		}
		cout << endl;
	}
}
int main()
{
	Matrix a;
	cout << "������һ��" << SIZE << "*" << SIZE << "�ľ���" << endl;
	a.set();
	cout << "ת��ǰ����Ϊ�� " << endl;
	a.print();
	cout << "ת�ú����Ϊ: " << endl;
	a.transpose();
	a.print();
	return 0;
}