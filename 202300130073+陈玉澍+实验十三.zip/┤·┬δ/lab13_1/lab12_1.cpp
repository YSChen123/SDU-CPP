#include <iostream>
#include <string>
#include <type_traits>
using namespace std;

class CException {
public:
	CException(const string &message):message(message){}
	~CException(){}
	const string& Reason()const { 
		cout << "Exception type: " << typeid(*this).name() << endl;
		return message;
	}
private:
	string message;
};

void fn1() throw(CException){
	cout << "Throw CException in fn1()" << endl;
	throw CException("exception thrown by fn1()");
}
int main() {
	cout << "In main function" << endl;
	try {
		fn1();
	}
	catch (CException& e) {
		e.Reason();
		cout << "Caught an exception: " << e.Reason() << endl;
	}
	cout << "Resume the exception of main()" << endl;
	return 0;
}