#include <iostream>
using namespace std;

class Vehicle {
public:
	Vehicle(int w, int MaxS) :Weight(w), MaxSpeed(MaxS) {
		cout << "Vehicle Constructing..." << endl;
	}
	void Run() {
		cout << "��ʼ����" << endl;
	}
	void Stop() {
		cout << "ֹͣ����" << endl;
	}
	int MaxSpeed;
	int Weight;
};
class Bicycle :virtual public Vehicle {
public:
	Bicycle(int h, int w, int s) :Height(h),Vehicle(w,s){
		cout << "Bicycle Constructing..." << endl;
	}
	int Height;
};
class Motorcar :virtual public Vehicle {
public:
	Motorcar(int sn,int w,int ms):SeatNum(sn),Vehicle(w,ms){
		cout << "Motorcar Constructing..." << endl;
	}
	int SeatNum;
};
class Motorcycle :public Bicycle, public Motorcar {
public:
	Motorcycle(int h,int sn,int w,int ms)
		: Bicycle(h,w,ms),Motorcar(sn,w,ms),Vehicle(w,ms){
		cout << "Motorcycle Constructing..." << endl;
	}
	void show() {
		cout << endl;
		cout << "MaxSpeed: " << MaxSpeed << endl
			<< "Weight: " << Weight << endl
			<< "Height: " << Height << endl
			<< "SeatNum: " << SeatNum << endl;
	}
};
int main() {
	Motorcycle M(1, 2, 30, 40);
	M.show();
	return 0;
}