#include <iostream>
#include <string>
using namespace std;
class Date {
public:
	Date(){}
	Date(int y,int m,int d):year(y),month(m),day(d) {}
	Date(const Date& d);
	~Date(){ }
	void SetDate();
	void ShowDate();
private:
	int year;
	int month;
	int day;
};
void Date::SetDate() {
	cout << "�꣺ " << endl;
	cin >> year;
	cout << "�£� " << endl;
	cin >> month;
	cout << "�գ� " << endl;
	cin >> day;
}
void Date::ShowDate() {
	cout << "Birthday:  " << year << "-" << month << "-" << day << endl;
}
Date::Date(const Date& d) {
	this->year = d.year;
	this->month = d.month;
	this->day = d.day;
}
class People {
public:
	People() {}
	People(char* name, char* number, char* sex, char* id, int year, int month, int day)
		:birthday(year, month, day) {
		strcpy_s(this->name, name);
		strcpy_s(this->number, number);
		strcpy_s(this->sex, sex);
		strcpy_s(this->id, id);
	}
	People(const People& p);
	void InputPeople();
	void ShowPeople();
private:
	char name[11];
	char number[7];
	char sex[3];
	Date birthday;
	char id[16];
};
void People::InputPeople() {
	cout << "������������Ա��Ϣ�� " << endl;
	cout << "������" << endl;
	cin >> name;
	cout << "���: " << endl;
	cin >> number;
	cout << "�Ա�" << endl;
	cin >> sex;
	cout << "����֤��: " << endl;
	cin >> id;
	birthday.SetDate();
}
People::People(const People& p) {
	strcpy_s(name, p.name);
	strcpy_s(number, p.number);
	strcpy_s(sex, p.sex);
	strcpy_s(id, p.id);
	birthday = p.birthday;
}
void People::ShowPeople() {
	cout << endl << "������ " << name
		<< endl << "��ţ� " << number
		<< endl << "�Ա� " << sex << endl;
	birthday.ShowDate();
	cout << "����֤��:  " << id << endl;
}
class Student :virtual public People{
public:
	Student(){}
	Student(const string &classNO, char* name, char* number, char* sex, char* id, int year, int month, int day)
	:People(name,number,sex,id,year,month,day),classNO(classNO){	
		this->classNO = classNO;
	}
	Student(const Student& s) :People(s){
		this->classNO = s.classNO;
	}
	void InputStudent() {
		People::InputPeople();
		cout << "��ţ� " << endl;
		cin >> classNO;
	}
	void ShowStudent() {
		People::ShowPeople();
		cout << "��ţ� " << classNO << endl;
	}
	void InputClassNO(const string &classNO) {
		this->classNO = classNO;
	}
	void showClassNO() {
		cout << "The classNO is: " << endl;
		cout << classNO << endl;
	}
private:
	string classNO;
};
class Teacher :virtual public People {
public:
	Teacher(){}
	Teacher(char *principalship,char *department, char* name,char* number, char* sex, char* id, int year, int month, int day)
	:People(name,number,sex,id,year,month,day){
		strcpy_s(this->principalship, principalship);
		strcpy_s(this->department, department);
	}
	Teacher(const Teacher& t):People(t) {
		strcpy_s(this->principalship, t.principalship);
		strcpy_s(this->department, t.department);
	}
	void ShowTeacher() {
		People::ShowPeople();
		cout << "ְ�� " << principalship << endl
			<< "���ţ� " << department << endl;
	}
	void InputTeacher() {
		cout << "��ʼ���ӽ�ʦ��Ϣ: " << endl;
		People::InputPeople();
		cout << "ְ��" << endl;
		cin >> principalship;
		cout << "���ţ�" << endl;
		cin >> department;
	}
private:
	char principalship[11];
	char department[21];
};
class Graduate :virtual public Student {
public:
	Graduate() { }
	Graduate(char* subject, Teacher adviser,const string &classNO, char* name, char* number, char* sex, char* id, int year, int month, int day)
		:Student(classNO, name, number, sex, id, year, month, day) ,People(name,number,sex,id,year,month,day),adviser(adviser){
		strcpy_s(this->subject, subject);
		this->InputClassNO(classNO);
	}
	Graduate(const Graduate& g) :Student(g),adviser(g.adviser) {
		strcpy_s(this->subject, g.subject);
	}
	void InputGraduate() {
		cout << "��ʼ����ѧ����Ϣ��" << endl;
		Student::InputStudent();
		cout << "רҵ�� " << endl;
		cin >> subject;
	}
	void ShowGraduate() {
		Student::ShowStudent();
		cout << "רҵ�� " << subject << endl
			 <<endl<< "��ʦ��Ϣ�� ";
		adviser.ShowTeacher();
	}
private:
	char subject[21];
	Teacher adviser;
};
class TA:public Graduate,public Teacher{
public:
	TA(){ }
	TA(char* subject, Teacher adviser, string classNO, char* name, char* number, char* sex, char* id, int year, int month, int day,char* principalship, char* department)
	:Graduate(subject,adviser,classNO,name,number,sex,id,year,month,day),
	 Teacher(principalship,department,name,number,sex,id,year,month,day),
	 People(name, number, sex, id, year, month, day) { }
	void InputG() {
		Graduate::Graduate();
	}
	void InputT() {
		Teacher::InputTeacher();
	}
	void Show() {
		cout <<endl<< "Graduate: ";
		Graduate::ShowGraduate();
	}
};

int main() {
	People A("a", "1", "��", "12567", 2004, 1, 1);
	Student B("1","b","2", "��", "45623", 2000, 12, 13);
	Teacher C("Master", "CS", "c", "22", "Ů", "11111", 1990, 2, 20);
	Graduate D("CS",C,"11","d","1222","��","12394",2000,10,20);
	TA ta("CS", C, "7", "ta", "1321", "Ů", "29002", 2000, 9, 11,"master","CS");

	A.ShowPeople();
	B.ShowStudent();
	C.ShowTeacher();
	cout<<endl<<"This is Graduate D: "<<endl;
	D.ShowGraduate();
	cout << endl << "This is TA ta: " << endl;
	ta.Show();
	return 0;

}