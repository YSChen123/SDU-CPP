#include <iostream>
using namespace std;
class Base1 {
public:
	int var;
	void fun() {
		cout << "Member of Base1" << endl;
	}
};
class Base2 {
public:
	int var;
	void fun() {
		cout << "Member of Base2" << endl;
	}
};
class Derived :public Base1, public Base2 {
public:
	int var;
	void fun() {
		cout << "Member of Derived" << endl;
	}
};
int main() {
	Derived d;
	cout << "Base pointer: " << &d << endl;
	cout << "Base1's var pointer: " << &(d.Base1::var) << endl;
	cout << "Base2's var pointer: " << &(d.Base2::var) << endl;
	cout << "Derived's var pointer: " << &(d.var) << endl;
	return 0;
}