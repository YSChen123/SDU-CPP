#include <iostream>
using namespace std;
class Base0 {
public:
	int var0;
	void fun0() { cout << "Member of Base0" << endl; }
};
class Base1 :public Base0 {
public:
	int var1;
};
class Base2 :public Base0 {
public:
	int var2;
};
class Derived :public Base1, public Base2 {
public:
	int var;
	void fun() { cout << "Member of Derived" << endl; }
};

int main() {
	Derived d;			//����Derived�����d
	d.Base1::var0 = 2;	//ʹ��ֱ�ӻ���
	d.Base1::fun0();
	d.Base2::var0 = 3;	//ʹ��ֱ�ӻ���
	d.Base2::fun0();
	cout << d.Base1::var0 << "  " << d.Base2::var0 << endl;  //�м���var0?
	cout << d.var0 << "  " << d.Base0::var0 << endl;
	return 0;
}