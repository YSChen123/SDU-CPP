#ifndef __FIRST_G_H__
#define __FIRST_G_H__

#include <iostream>
using namespace std;
#include <string>

//CU
class QD_CU {
public:
	int pc;
	string cu;

	QD_CU(string cu, int pc = 0);
};

//ALU
class QD_ALU {
public:
	int num;
	string alu;

	QD_ALU(string alu, int num=0);
	int add(int a, int b);
	int sub(int a, int b);
};

//Memory
class QD_Memory {
public:
	int size;
	int* arr;

	QD_Memory(int size);
};

//In
class QD_In {
public:
	int pre;
	string in;

	QD_In(string in);
	int input();
};

//Out
class QD_Out {
public:
	string out;

	QD_Out(string out);
	void display(int a);
};

//Computer
class Computer {
public:
	Computer(string cu, string alu, int size, string in, string out);
	void run();

	QD_CU cu;
	QD_ALU alu;
	QD_Memory memory;
	QD_In in;
	QD_Out out;
};
#endif