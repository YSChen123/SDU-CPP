#ifndef __SECOND_G_H__
#define __SECOND_G_H__
#include "First-G.h"
#include <iostream>
using namespace std;
#include <string>

class Extended_ALU :public QD_ALU {
public:
	Extended_ALU(string name, int num = 0);
	int mul(int a,int b);
	int div(int a,int b);
};

class Computer_2 :public Computer {
public:
	Computer_2(string cu, string alu, int size, string in, string out);
	void run();
private:
	Extended_ALU e_alu;
};

#endif