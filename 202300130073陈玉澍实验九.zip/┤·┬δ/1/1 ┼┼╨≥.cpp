#include <iostream>
using namespace std;

template <typename T>
void mySwap(T& a, T& b) {
	T temp = a;
	a = b;
	b = temp;
}
template <typename T>
void outputArray(const T* array, int count) {
	for (int i = 0; i < count; i++) {
		cout << array[i] << " ";
	}
	cout << endl;
}
template <typename T>
void sortArray(T* array, int count) {
	for (int i = 0; i < count-1; i++) {
		for (int j = 0; j < count-i-1; j++) {
			if (array[j] > array[j+1]) {
				mySwap(array[j], array[j + 1]);
			}
		}
	}
}
int main() {
	int a[10] = { 9,2,4,5,1,3,7,8,10,6 };
	cout << "int sort result: " << endl;
	sortArray(a, 10);
	outputArray(a, 10);
	return 0;
}