#ifndef _LINE_H_
#define _LINE_H_
#include "Point.h"
#include "Shape.h"
#include <iostream>
using namespace std;

class Line :public Shape {
public:
	Line(const Point& p1, const Point& p2) {
		this->p1 = p1;
		this->p2 = p2;
	}
	virtual void show() {
		cout << "Line from p1:(" << p1.getX() << "," << p1.getY() << ") to p2:(" << p2.getX() << ","
			<< p2.getY() << ")" << endl;
	}
private:
	Point p1, p2;
};
#endif 