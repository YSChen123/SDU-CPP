#ifndef _SHAPE_H_
#define _SHAPE_H_

class Shape {
public:
	virtual void show() = 0;
	virtual ~Shape(){}
};
#endif
