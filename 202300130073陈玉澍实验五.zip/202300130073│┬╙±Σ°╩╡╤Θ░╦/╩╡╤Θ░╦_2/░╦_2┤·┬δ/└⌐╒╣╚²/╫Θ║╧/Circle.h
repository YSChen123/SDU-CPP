#ifndef _CIRCLE_H_
#define _CIRCLE_H_
#include <iostream>
using namespace std;
#include "Point.h"

class Circle {
public:
	Circle(const Point &c,float r):center(c),itsRadius(r){}
	void show() {
		cout << "Circle center:(" << center.getX() << "," << center.getY() << ") radius: "
			<< itsRadius << endl;
	}
	float getR()const { return itsRadius; }
private:
	Point center;
	float itsRadius;
};
#endif