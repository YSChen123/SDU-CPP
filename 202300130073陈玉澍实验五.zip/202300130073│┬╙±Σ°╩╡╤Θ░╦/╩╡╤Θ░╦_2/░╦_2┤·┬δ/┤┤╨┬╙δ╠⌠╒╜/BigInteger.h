#ifndef _BIGINTEGER_H_
#define _BIGINTEGER_H_
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
#define MAX 1000

class BigInteger {
private:
	int num[MAX];
	int len;
public:
	BigInteger() {
		memset(num, 0, sizeof(num));
		len = 1;
	}
	BigInteger(const string& s) {
		memset(num, 0, sizeof(num));
		len = s.length();
		for (int i = 0; i < len; i++) {
			num[i] = s[len - i - 1] - '0';
		}
	}

	BigInteger operator+(const BigInteger& b)const {
		BigInteger res;
		res.len = max(this->len, b.len);
		for (int i = 0; i < res.len; i++) {
			res.num[i] += (this->num[i] + b.num[i]);
			res.num[i + 1] += res.num[i] / 10;
			res.num[i] %= 10;
		}
		if (res.num[res.len] > 0)
			res.len++;
		return res;
	}
	BigInteger operator-(const BigInteger& b)const {
		BigInteger res;
		res.len = max(this->len, b.len);
		//cout << res.len << endl;
		for (int i = 0; i < res.len; i++) {
			res.num[i] += this->num[i] - b.num[i];
			if (res.num[i] < 0) {
				res.num[i] += 10;
				res.num[i + 1]--;
			}
		}
		while (res.len > 1 && res.num[res.len - 1] == 0) {
	//		cout << res.num[len - 1]<<"   ";
			res.len--;
	//		cout << res.len <<endl;
		}
		return res;
	}
	BigInteger operator*(const BigInteger& b)const {
		BigInteger res;
		for (int i = 0; i < this->len; i++) {
			for (int j = 0; j < b.len; j++) {
				res.num[i + j] += this->num[i] * b.num[j];
				res.num[i + j + 1] += res.num[i + j] / 10;
				res.num[i + j] %= 10;
			}
		}
		res.len = this->len * b.len;
		while (res.len > 1 && res.num[res.len - 1] == 0) {
			res.len--;
		}
		return res;
	}
	BigInteger operator/(const BigInteger& b)const {
		BigInteger res;
		res.len = max(this->len,b.len);
		BigInteger cur;
		for (int i = res.len - 1; i >= 0; i--) {
			cur = cur * (to_string(10)) + to_string(num[i]);
			int cnt=0;
			while (cur >= b) {
				cur = cur - b;
				cnt++;
			}
			res.num[i] = cnt;
			cur =cur- b.operator* (to_string(cnt));
		}
		while (res.len > 1 && res.num[res.len - 1] == 0) {
			res.len--;
		}
		return res;
	}
	bool operator<(const BigInteger& b)const {
		for (int i = len - 1; i >= 0; i--) {
			if (num[i] < b.num[i])return true;
			else if (num[i] > b.num[i])return false;
		}
		return false;
	}
	bool operator>(const BigInteger&b) const {
		int length = max(len, b.len);
		for (int i = length - 1; i >= 0; i--) {
			if (num[i] > b.num[i]) return true;
			else if (num[i] < b.num[i]) return false;
		}
		return false;
	}
	bool operator==(const BigInteger&b) const {
		int length= max(len, b.len);
		for (int i = 0; i < length; i++) {
			if (num[i] != b.num[i]) return false;
		}
		return true;
	}
	bool operator>=(const BigInteger& b)const {
		return (*this) > b || (*this == b);
	}
	friend ostream& operator<<(ostream& out, const BigInteger &b) {
		for (int i = b.len - 1; i >= 0; i--) {
			out << b.num[i];
		}
		return out;
	}
};

#endif