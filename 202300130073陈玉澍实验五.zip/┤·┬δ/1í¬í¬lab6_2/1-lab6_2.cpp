#include <iostream>
using namespace std;
void transpose(int (*m)[3]) {
	for (int i = 0; i < 3; i++) {
		for (int j = i+1; j < 3; j++) {
			int temp = m[i][j];
			m[i][j] = m[j][i];
			m[j][i] = temp;
		}
	}
}
int main()
{
	int (*p)[3] = new int[3][3];
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			cin >> p[i][j];
		}
	}
	cout << endl;
	cout << "ԭ����Ϊ: " << endl;
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			cout<< p[i][j]<<"  ";
		}
		cout << endl;
	}
	transpose(p);
	cout << "����ת�ú��Ϊ: " << endl;
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			cout << p[i][j] << "  ";
		}
		cout << endl;
	}
	delete[] p;
	return 0;
}