#include <iostream>
using namespace std;
#include <string>

class Employee
{
public:
	Employee(const string& n, const string& s, const string& c, const string& z);
	void setName(const string& n);
	void display();
private:
	string name;
	string street;
	string city;
	string zip;
};
Employee::Employee(const string& n, const string& s, const string& c, const string& z)
	:name(n), street(s), city(c), zip(z){}
void Employee::setName(const string& n) {
	name = n;
}
void Employee::display() {
	cout << name << "\t" << street << "\t"
		<< city << "\t" << zip<<endl;
}
int main()
{
	Employee emp[5] = {
		Employee("aa", "aaa���1��", "����", "111111"),
		Employee("bb", "bbb���2��", "�Ϻ�", "222222"),
		Employee("cc", "ccc���3��", "�ൺ", "333333"),
		Employee("dd", "ddd���4��", "����", "444444"),
		Employee("ee", "eee���5��", "���", "555555")
	};
	for (int i = 0; i < 5; i++) {
		emp[i].display();
	}
	return 0;
}