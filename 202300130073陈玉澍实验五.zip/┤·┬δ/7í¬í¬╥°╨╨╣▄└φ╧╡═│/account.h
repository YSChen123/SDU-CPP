#ifndef _ACCOUNT_H_
#define _ACCOUNT_H_
#include "date.h"
#include <string>
#include <iostream>
using namespace std;
class SavingsAccount
{
private:
	string id;
	double balance;
	double rate;
	Date lastDate;
	double accumulation;
	static double total;
	void record(const Date& date, double amount, const string& desc);
	void error(const string& msg)const;
	double accumulate(const Date& date)const {
		return accumulation + balance * date.distance(lastDate);
	}
public:
	SavingsAccount(const Date& date, const string& id, double rate);
	const string& getid()const { return id; }
	double getBalance()const { return balance; }
	double getRate()const { return rate; }
	static double getTotal() { return total; }
	void deposit(const Date& date, double amount, const string& desc);
	void withdraw(const Date& date, double amount, const string& desc);
	void settle(const Date& date);
	void show()const;
};
#endif 