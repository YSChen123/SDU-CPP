#include "Rectangle.h"
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	Rectangle rect;
	rect.initRectangle(2, 3, 20, 10);
	rect.move(3, 2);
	cout << "The date of rect(x,y,w,h): " << endl;
	cout << rect.getX() << ", "
		<< rect.getY() << ", "
		<< rect.getH() << ", "
		<< rect.getW() << endl;
	return 0;
}