#include <iostream>
using namespace std;
class BaseClass {
public:
	BaseClass(int num=0):Number(num) { cout << "Constructing BaseClass. " << endl; }
	~BaseClass() { cout << "Destructing BaseClass." << endl; }
private:
	int Number;
};
class DerivedClass :public BaseClass {
public:
	DerivedClass(int num=0):BaseClass(num){ cout << "Constructing DerivedClass. " << endl; }
	~DerivedClass() { cout << "Destructing DerivedClass." << endl; }
};
int main() {
	DerivedClass obj(10);
	return 0;
}