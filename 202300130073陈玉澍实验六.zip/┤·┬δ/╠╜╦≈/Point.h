#ifndef _POINT_H_
#define _POINT_H_
class Point {
public:
	Point(float x=0,float y=0):x(x),y(y){ }
	void move(float offx, float offy) {
		x += offx;
		y += offy;
	}
	float getX() const { return x; }
	float getY() const { return y; }
private:
	float x, y;
};
#endif