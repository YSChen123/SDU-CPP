#ifndef _RECTANGLE_H_
#define _RECTANGLE_H_
#include "Point.h"
class Rectangle :public Point {
public:
	Rectangle(float x, float y, float w, float h) 
		:p(x,y),w(w),h(h){ }
	void move(float offx, float offy) {
		p.move(offx, offy);
	}
	float getX() const { return p.getX(); }
	float getY() const { return p.getY(); }
	float getH()const { return h; }
	float getW()const { return w; }
private:
	float w, h;
	Point p;
};
#endif