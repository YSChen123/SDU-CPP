#include <iostream>
#include "node.h"
using namespace std;

int main() {
	cout << "please enter 10 integers: " << endl;
	Node<int>* head = NULL;
	Node<int>* pre = NULL;
	for (int i = 0; i < 10; i++) {
		int val;
		cin >> val;
		Node<int>* NewNode = new Node<int>(val);
		if (head == NULL) {
			head = NewNode;
			pre = head;
		}
		else {
			pre->next = NewNode;
			pre = pre->nextNode();
		}
	}

	cout << "List: " << endl;
	head->MyPrint(head);

	cout << "please enter an integer waiting for searching: " << endl;
	int key;
	cin >> key;
	head->deleteData(head, key);
	cout << "After deleting: " << endl;
	head->MyPrint(head);
	return 0;
}