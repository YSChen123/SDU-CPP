#include "queue.h"
#include <iostream>
using namespace std;

void test() {
	Queue<int> q;
	for (int i=1; i <= 5; i++) {
		q.inQueue(i);
	}
	q.show();
	cout << endl;
	while (!q.isEmpty()) {
		cout << "Dequeued: " << q.outQueue()<<endl;
	}
	cout << endl;
	cout << "The list now has: " << q.getSize() << endl;
}
int main() {
	test();
	return 0;
}