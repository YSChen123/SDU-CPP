#ifndef QUEUE_H
#define QUEUE_H
#include <iostream>
using namespace std;
#include "link.h"

template <class T>
class Queue {
private:
	LinkedList<T> list;
public:
	Queue(){}
	void inQueue(const T& item) {
		list.insertRear(item);
	}
	T outQueue() {
		if (list.isEmpty()) {
			cout << "Error:There is nothing in Queue!" << endl;
			return -1;
		}
		return list.deleteFront();
	}
	bool isEmpty()const {
		return list.isEmpty();
	}
	int getSize()const {
		return list.getSize();
	}
	void show(){
		cout << "The list is: " << endl;
		list.reset();
		while (!list.endOfList()) {
			cout << list.data() << " ";
			list.next();
		}
	}
	~Queue() {}
};

#endif // !QUEUE_H
