#include "Calculator.h"
#include <iostream>
using namespace std;
#include <sstream>
#include <cmath>

inline double stringToDouble(const string& str) {
	istringstream stream(str);
	double result;
	stream >> result;
	return result;
}

void Calculator::enter(double num) {
	s.push(num);
}

bool Calculator::isOp(char c) {
	return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

int Calculator::Precedence(char c) {
	switch (c) {
	case '+':
	case '-':
		return 1;
	case '*':
	case '/':
		return 2;
	case '^':
		return 3;
	default:
		return 0;
	}
}

bool Calculator::getTwoOperands(double& opnd1, double& opnd2) {
	if (s.isEmpty()) {
		cerr << "Missing right operand!" << endl;
		return false;
	}
	opnd1 = s.pop();
	if (s.isEmpty()) {
		cerr << "Missing left operand!" << endl;
		return false;
	}
	opnd2 = s.pop();
	return true;
}

void Calculator::compute(char op) {
	double operand1, operand2;
	bool result = getTwoOperands(operand1, operand2);
	if (result) {
		switch (op) {
		case '+':
			s.push(operand2 + operand1); break;
		case '-':
			s.push(operand2 - operand1); break;
		case '*':
			s.push(operand2 * operand1); break;
		case '/':
			if (operand1 == 0) {
				cerr << "Divided by 0!" << endl;
				s.clear();
			}
			else
				s.push(operand2 / operand1);
			break;
		case '^':
			s.push(pow(operand2, operand1)); break;
		default:
			cerr << "Unrecognized operator!" << endl;
			break;
		}
		cout << "= " << s.peek() << " ";
	}
	else
		s.clear();
}
string Calculator::infixToPostfix(const string& infix) {
	Stack<char>ops;
	vector<char> postfix;

	for (char ch : infix)
	{
		if (isspace(ch))continue;
		if (isdigit(ch))
		{
			postfix.push_back(ch);
		}
		else if (ch == '(')
		{
			ops.push(ch);
		}
		else if (ch == ')')
		{
			while (!ops.isEmpty() && ops.peek() != '(')
			{
				postfix.push_back(ops.peek());
				ops.pop();
			}
			//����������
			if (!ops.isEmpty())
			{
				ops.pop();
			}
		}
		else if (isOp(ch))
		{
			while (!ops.isEmpty() && Precedence(ops.peek()) >= Precedence(ch))
			{
				postfix.push_back(ops.peek());
				ops.pop();
			}
			//ջΪ�ջ������ȼ��׾�ֱ�Ӽ���5
			ops.push(ch);
		}
	}

	while (!ops.isEmpty())
	{
		postfix.push_back(ops.peek());
		ops.pop();
	}
	string result;
	for (char ch : postfix) {
		result += ch;
		result += ' ';
	}
	return result;
}
double Calculator::run() {
	string postfix=infixToPostfix(infix);
	for(char c:postfix){
		if (isspace(c))continue;
		if (isdigit(c)) {
			stringstream ss;
			ss << c;
			double val;
			ss >> val;
			s.push(val);
		}
		else if (isOp(c)) {
			compute(c);
		}
	}
	return s.peek();
}

void Calculator::clear() {
	s.clear();
}

