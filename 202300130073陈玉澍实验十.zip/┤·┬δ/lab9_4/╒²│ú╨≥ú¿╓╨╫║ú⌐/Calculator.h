#ifndef CALCULATOR_H
#define CALCULATOR_H
#include "Stack.h"
#include <vector>

class Calculator {
public:
	Calculator(string in):infix(in){}
	Stack<double> s;
	string infix;
	void enter(double num);
	bool getTwoOperands(double& opnd1, double& opnd2);
	void compute(char op);
	bool isOp(char c);

	string infixToPostfix(const string& infix);
	int Precedence(char c);
	double run();
	void clear();
};
#endif // !CALCULATOR_H