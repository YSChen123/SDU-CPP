#ifndef LINKED_LIST_H
#define LINKED_LIST_H
#include "dnode.h"
#include <iostream>
using namespace std;

template<class T>
class LinkedList {
private:
	DNode<T>* head;
	DNode<T>* tail;
public:
	LinkedList();
	void insertRight(const T& item);
	void insertLeft(const T& item);
	void deleteNode(const T& item);
	void display();
	~LinkedList();
};

template<class T>
LinkedList<T>::LinkedList():head(NULL),tail(NULL) { }

template<class T>
void LinkedList<T>::insertLeft(const T& item) {
	DNode<T>* newNode = new DNode<T>(item);
	if (head == NULL) {
		head = tail = newNode;
	}
	else {
		newNode->left = NULL;
		newNode->right = head;
		head->left = newNode;
		head = newNode;
	}
}

template<class T>
void LinkedList<T>::insertRight(const T& item) {
	DNode<T>* newNode = new DNode<T>(item);
	if (tail == NULL) {
		head = tail = newNode;
	}
	else {
		tail->right = newNode;
		newNode->right = NULL;
		newNode->left = tail;
		tail = newNode;
	}
}


template<class T>
void LinkedList<T>::deleteNode(const T&item) {
	DNode<T> *index=head;
	while (index != NULL && index->data != item) {
		index = index->right;
	}
	if (index != NULL) {
		if (index == head) {
			head = head->right;
			if (head != NULL) {
				head->left = NULL;
			}
			else {
				tail == NULL;
			}
		}
		else {
			index->left->right = index->right;
			if (index->right != NULL) {
				index->right->left = index->left;
			}
			else {
				tail = index->left;
			}
		}
		delete index;
	}
}

template<class T>
void LinkedList<T>::display() {
	DNode<T>* index = head;
	while (index != NULL) {
		cout << index->data << " ";
		index = index->right;
	}
	cout << endl;
}

template<class T>
LinkedList<T>::~LinkedList() {
	while (head != NULL) {
		DNode<T>* temp = head;
		head = head->nextNodeRight();
		delete temp;
	}
	tail = NULL;
}
#endif