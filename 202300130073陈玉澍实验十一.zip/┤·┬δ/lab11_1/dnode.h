#ifndef DOUBLY_LINKED_NODE_CLASS
#define DOUBLY_LINKED_NODE_CLASS

template <class T>
class DNode {
public:
	DNode<T>* left;
	DNode<T>* right;
public:
	T data;

	DNode(void);
	DNode(const T& item);

	void insertRight(DNode<T>* p);
	void insertLeft(DNode<T>* p);
	DNode<T>* deleteNode(void);
	DNode<T>* nextNodeRight(void)const;
	DNode<T>* nextNodeLeft(void)const;
};

template<class T>
DNode<T>::DNode(void) {
	left = right = this;
}

template<class T>
DNode<T>::DNode(const T& item) {
	left = right = this;
	data = item;
}

template<class T>
void DNode<T>::insertRight(DNode<T>* p) {
	p->right = right;
	right->left = p;

	p->left = this;
	this->right = p;
}

template<class T>
void DNode<T>::insertLeft(DNode<T>* p) {
	p->left = left;
	left->right = p;

	p->right = p;
	left = p;
}

template<class T>
DNode<T>* DNode<T>::deleteNode(void) {
	left->right = right;
	right->left = left;
	return this;
}

template<class T>
DNode<T>* DNode<T>::nextNodeLeft(void)const {
	return left;
}

template <class T>
DNode<T>* DNode<T>::nextNodeRight(void)const {
	return right;
}


#endif