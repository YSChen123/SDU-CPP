#include "dnode.h"
#include "LinkedList.h"
#include <iostream>
using namespace std;

void test() {
	LinkedList<int> list;
	list.insertLeft(1);
	list.insertLeft(2);
	list.insertRight(3);
	list.insertRight(4);
	list.insertLeft(5);
	list.insertRight(6);

	cout << "List is : " << endl;
	list.display();

	cout << "Please enter a number to remove from list : "<<endl;
	int key;
	cin >> key;
	list.deleteNode(key);
	cout << "Now the list is : " << endl;
	list.display();
}

int main() {
	test();
	
	return 0;
}