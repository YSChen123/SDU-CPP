#ifndef BUBBLE_SORT_H
#define BUBBLE_SORT_H
#include <iostream>
using namespace std;

template <class T>
void swapDatab(T& x, T& y) {
	T temp = x;
	x = y;
	y = temp;
}

template <class T>
void bubbleSort(T A[], int n) {
	int i = n - 1, j;
	int lastExchangeIndex;
	while (i > 0) {
		lastExchangeIndex = 0;
		for (j = 0; j < i; j++) {
			if (A[j + 1] < A[j]) {
				swapDatab(A[j], A[j + 1]);
				lastExchangeIndex = j;
			}
		}
		i = lastExchangeIndex;
		for (int k = 0; k < n; k++) {
			cout << A[k] << " ";
		}
		cout << endl;
	}
}
#endif // !BUBBLE_SORT_H
