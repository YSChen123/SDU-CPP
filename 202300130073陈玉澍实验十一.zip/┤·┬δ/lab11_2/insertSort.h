#ifndef INSERT_SORT_H
#define INSERT_SORT_H
#include <iostream>
using namespace std;

template <class T>
void insertSort(T A[], int n) {
	T temp;
	for (int i = 1; i < n; i++) {
		temp = A[i];
		int j = i;
		while (j > 0 && temp < A[j - 1]) {
			A[j] = A[j - 1];
			j--;
		}
		A[j] = temp;
		for (int k = 0; k < n; k++) {
			cout << A[k] << " ";
		}
		cout << endl;
	}
}

#endif // !INSERT_SORT_H
