#ifndef SWAP_INSERT_H
#define SWAP_INSERT_H
#include <iostream>
using namespace std;

template<class T>
void swapData(T &x,T&y) {
	T temp= x;
	x = y;
	y = temp;
}

template <class T>
void selectSort(T A[], int n) {
	int minIndex;
	for (int i = 0; i < n-1; i++) {
		minIndex = i;
		int j;
		for (j = i + 1; j < n; j++) {
			if (A[j] < A[minIndex]) {
				minIndex = j;
			}
		}
		swapData(A[i], A[minIndex]);
		for (int k = 0; k < n; k++) {
			cout << A[k] << " ";
		}
		cout << endl;
	}
}
#endif // !SWAP_INSERT_H
