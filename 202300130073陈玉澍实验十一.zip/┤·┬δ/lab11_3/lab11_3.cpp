#include <iostream>
using namespace std;

template <class T>
int binarySearch(T list[], int n, T key) {
	int mid, low, high;
	T midvalue;
	low = 0;
	high = n - 1;
	while (low <= high) {
		mid = (low + high) / 2;
		midvalue = list[mid];
		if(key==midvalue)
			return mid;
		else if(key<midvalue){
			high = mid - 1;
		}
		else {
			low = mid + 1;
		}
	}
	return -1;
}

int main() {
	int i, n;
	int datal[] = { 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20 };
	cout << "��������Ҫ���ҵ�����(1~20)�� " << endl;
	cin >> n;
	cout << "����Ϊ�� " << endl;
	for (int i = 0; i < 20; i++) {
		cout << datal[i] << " ";
	}
	cout << endl;
	i = binarySearch(datal, 20, n);
	if (i == -1) {
		cout << "û�ҵ�������" << endl;
	}
	else {
		cout << n << "�ǵ�" << i + 1 << "������" << endl;
	}
	return 0;
}
