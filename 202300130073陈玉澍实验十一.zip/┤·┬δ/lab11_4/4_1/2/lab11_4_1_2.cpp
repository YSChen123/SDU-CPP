#include <iostream>
using namespace std;
#include "head_2.h"

int main() {
	int datal[] = { 1,3,5,7,9,11,13,15,17,19,2,4,6,8,10,12,14,16,18,20 };
	int* p[20];
	for (int i = 0; i < 20; i++) {
		p[i] = &datal[i];
	}
	bubbleSort(p, 20);
	for (int i = 0; i < 20; i++) {
		cout << *p[i] << " ";
	}
	cout << endl;
	return 0;
}