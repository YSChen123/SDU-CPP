#include"Power.h"
#include<iostream>
using namespace std;
int main() {
	int x = 2;

	cout << Power<4>::value(x) << endl;
	cout << power<6>(x) << endl;

	return 0;
}