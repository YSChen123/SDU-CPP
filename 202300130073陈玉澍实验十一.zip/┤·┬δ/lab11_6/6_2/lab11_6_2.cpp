#include <iostream>
using namespace std;

template <typename T>
void print(T& t) {
	cout << t << endl;
}

template <typename T,typename...TypeArgs>
void func(const T& t, const TypeArgs&...args) {
	cout << sizeof...(args) << endl;
	(print(args), ...);
}

int main() {
	func(3, 4.5, "hello world!");
	return 0;
}