#include <iostream>
using namespace std;
#include <algorithm>
#include <vector>

void MyPrint(vector<int>&v) {
	for (vector<int>::iterator it = v.begin(); it != v.end(); it++) {
		cout << *it << " ";
	}
	cout << endl;
}

int main() {
	vector<int> v = { 2,1,3,4,9,6,5,8 };
	int toFind = 9;
	vector<int>::iterator loc = find(v.begin(), v.end(), toFind);

	cout << "Array at first: " << endl;
	MyPrint(v);

	if (loc != v.end()) {
		cout << "Find " << toFind << " at position: " << distance(v.begin(), loc) << endl;
	}
	else {
		cout << "Value " << toFind << "not found" << endl;
	}

	sort(v.begin(), v.end());
	cout << "Array sorted in ascending order: "<<endl;
	MyPrint(v);

	sort(v.begin(), v.end(), greater<int>());
	cout << "Array sorted in descending order: " << endl;
	MyPrint(v);
}