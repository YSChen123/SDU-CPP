#include <iostream>
#include <string>
using namespace std;

int main() {
	//string line;
	//cout << "Type a line terminated by 't' " << endl;
	//getline(cin, line, 't');
	//cout << line<<endl;

	//get��һ�֣�
	/*cout << "Type a line terminated by 't' " << endl;
	char ch[50];
	cin.get(ch, 40, 't');
	cout << ch << endl;*/

	//get�ڶ��֣�
	cout << "Type a line terminated by 't' " << endl;
	char ch;
	while ((ch = cin.get()) != 't') {
		cout << ch;
	}
	cout << endl;
	return 0;
}